// Google Login Page Interactive Features

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all interactive features
    initializeInputLabels();
    initializePasswordToggle();
    initializeFormValidation();
    initializeKeyboardNavigation();
    initializeLoadingStates();
});

/**
 * Handle floating labels for Google-style inputs
 */
function initializeInputLabels() {
    const inputs = document.querySelectorAll('.google-input');
    
    inputs.forEach(input => {
        // Check if input has value on page load
        if (input.value.trim() !== '') {
            input.classList.add('has-value');
        }
        
        // Handle input events
        input.addEventListener('input', function() {
            if (this.value.trim() !== '') {
                this.classList.add('has-value');
            } else {
                this.classList.remove('has-value');
            }
        });
        
        // Handle focus events
        input.addEventListener('focus', function() {
            this.classList.add('focused');
        });
        
        // Handle blur events
        input.addEventListener('blur', function() {
            this.classList.remove('focused');
        });
    });
}

/**
 * Handle show/hide password functionality
 */
function initializePasswordToggle() {
    const showPasswordCheckbox = document.getElementById('showPassword');
    const passwordInput = document.getElementById('password');
    
    if (showPasswordCheckbox && passwordInput) {
        showPasswordCheckbox.addEventListener('change', function() {
            if (this.checked) {
                passwordInput.type = 'text';
            } else {
                passwordInput.type = 'password';
            }
        });
    }
}

/**
 * Enhanced form validation with Google-style error handling
 */
function initializeFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const isValid = validateForm(this);
            
            if (!isValid) {
                e.preventDefault();
                return false;
            }
            
            // Add loading state to submit button
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Verifying...';
            }
        });
    });
}

/**
 * Validate form fields
 */
function validateForm(form) {
    let isValid = true;
    const emailInput = form.querySelector('input[name="email"]');
    const passwordInput = form.querySelector('input[name="password"]');
    
    // Clear previous errors
    clearFieldErrors();
    
    // Validate email
    if (emailInput) {
        const email = emailInput.value.trim();
        if (!email) {
            showFieldError(emailInput, 'Please enter an email address');
            isValid = false;
        } else if (!isValidEmail(email)) {
            showFieldError(emailInput, 'Please enter a valid email address');
            isValid = false;
        }
    }
    
    // Validate password
    if (passwordInput) {
        const password = passwordInput.value;
        if (!password) {
            showFieldError(passwordInput, 'Please enter your password');
            isValid = false;
        }
    }
    
    return isValid;
}

/**
 * Show field-specific error
 */
function showFieldError(input, message) {
    input.classList.add('is-invalid');
    
    // Remove existing error message
    const existingError = input.parentNode.querySelector('.invalid-feedback');
    if (existingError) {
        existingError.remove();
    }
    
    // Add new error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'invalid-feedback d-block';
    errorDiv.innerHTML = `<i class="fas fa-exclamation-triangle me-1"></i>${message}`;
    input.parentNode.appendChild(errorDiv);
}

/**
 * Clear all field errors
 */
function clearFieldErrors() {
    const invalidInputs = document.querySelectorAll('.is-invalid');
    const errorMessages = document.querySelectorAll('.invalid-feedback');
    
    invalidInputs.forEach(input => input.classList.remove('is-invalid'));
    errorMessages.forEach(error => error.remove());
}

/**
 * Email validation helper
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Keyboard navigation enhancement
 */
function initializeKeyboardNavigation() {
    // Enter key navigation
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    
    if (emailInput) {
        emailInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const form = this.closest('form');
                if (form) {
                    form.dispatchEvent(new Event('submit', { cancelable: true }));
                }
            }
        });
    }
    
    if (passwordInput) {
        passwordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const form = this.closest('form');
                if (form) {
                    form.dispatchEvent(new Event('submit', { cancelable: true }));
                }
            }
        });
    }
}

/**
 * Button loading states
 */
function initializeLoadingStates() {
    const buttons = document.querySelectorAll('.google-btn-primary, .google-btn-outline');
    
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            if (this.type === 'submit') {
                // Loading state will be handled by form submission
                return;
            }
            
            // For other buttons, add loading state
            const originalText = this.innerHTML;
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
            
            // Simulate loading (remove in real implementation)
            setTimeout(() => {
                this.disabled = false;
                this.innerHTML = originalText;
            }, 1000);
        });
    });
}

/**
 * Auto-dismiss alerts after 5 seconds
 */
function initializeAlerts() {
    const alerts = document.querySelectorAll('.alert');
    
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
}

/**
 * Smooth scrolling for better UX
 */
function smoothScrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

/**
 * Handle browser back button
 */
window.addEventListener('popstate', function(e) {
    // Clear any loading states
    const buttons = document.querySelectorAll('button[disabled]');
    buttons.forEach(button => {
        button.disabled = false;
        if (button.innerHTML.includes('spinner')) {
            button.innerHTML = button.innerHTML.includes('Verifying') ? 'Next' : 'Next';
        }
    });
});

/**
 * Focus management for accessibility
 */
function manageFocus() {
    const firstInput = document.querySelector('.google-input');
    if (firstInput) {
        firstInput.focus();
    }
}

// Initialize focus management when page loads
window.addEventListener('load', manageFocus);

/**
 * Responsive design helpers
 */
function handleResize() {
    const vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);
}

window.addEventListener('resize', handleResize);
window.addEventListener('orientationchange', handleResize);
handleResize(); // Initial call

/**
 * Prevent zoom on iOS when focusing inputs
 */
if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {
    const inputs = document.querySelectorAll('input[type="email"], input[type="password"]');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.style.fontSize = '16px';
        });
    });
}
