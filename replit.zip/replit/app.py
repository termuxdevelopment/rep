import os
import logging
from flask import Flask, render_template, request, redirect, url_for, flash

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "fake-google-login-secret-key")

@app.route('/')
def index():
    """Main login page - email entry"""
    return render_template('index.html')

@app.route('/signin/identifier', methods=['POST'])
def signin_identifier():
    """Handle email submission and redirect to password page"""
    email = request.form.get('email', '').strip()
    
    if not email:
        flash('Please enter an email address', 'error')
        return redirect(url_for('index'))
    
    # Simulate email validation
    if '@' not in email:
        flash('Please enter a valid email address', 'error')
        return redirect(url_for('index'))
    
    # Redirect to password page with email
    return redirect(url_for('enter_password', email=email))

@app.route('/signin/password')
def enter_password():
    """Password entry page"""
    email = request.args.get('email', '')
    if not email:
        return redirect(url_for('index'))
    
    return render_template('enterpassword.html', email=email)

@app.route('/signin/challenge', methods=['POST'])
def signin_challenge():
    """Handle password submission"""
    email = request.form.get('email', '')
    password = request.form.get('password', '')
    
    if not password:
        flash('Please enter your password', 'error')
        return redirect(url_for('enter_password', email=email))
    
    # Simulate login (always fails for demo purposes)
    flash('Wrong password. Try again or click Forgot password to reset it.', 'error')
    return redirect(url_for('enter_password', email=email))

@app.route('/forgot')
def forgot_password():
    """Forgot password page (placeholder)"""
    return render_template('index.html', forgot=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
